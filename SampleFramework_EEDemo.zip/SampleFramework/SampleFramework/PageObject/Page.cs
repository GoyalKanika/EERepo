﻿using OpenQA.Selenium;
using SampleFramework.Utilities;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleFramework.PageObject
{
    public class Page : Base {
        public Page(IWebDriver driver) : base(driver) { }

        public IList<IWebElement> GetAllAnchorLinks()
        {
            return driver.FindElements(By.TagName("a"));
        }

        public IList<IWebElement> GetAllLinkTags()
        {
            return driver.FindElements(By.TagName("link"));
        }
        public IList<IWebElement> GetAllAreaTags()
        {
            return driver.FindElements(By.TagName("area"));
        }
        public IList<IWebElement> GetAllbaseTags()
        {
            return driver.FindElements(By.TagName("base"));
        }

       
}
        
}

