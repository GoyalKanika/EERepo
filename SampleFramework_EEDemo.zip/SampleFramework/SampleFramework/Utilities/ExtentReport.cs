﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;

namespace SampleFramework.Utilities
{
    public static class ExtentReport
    {
        private static ExtentReports _extentReports;
        private static ExtentSparkReporter _htmlReporter;
        private static ExtentTest _test;

        public static void InitializeReport()
        {
            string reportPath = Path.Combine(Directory.GetCurrentDirectory(), "TestResults", "ExtentReport.html");
            Directory.CreateDirectory(Path.GetDirectoryName(reportPath));

            _htmlReporter = new ExtentSparkReporter(reportPath);

           // _htmlReporter = new ExtentSparkReporter("TestResults/ExtentReport.html");
            _htmlReporter.Config.DocumentTitle = "Automation Test Report";
            _htmlReporter.Config.ReportName = "Link Validation Report";

            _extentReports = new ExtentReports();
            _extentReports.AttachReporter(_htmlReporter);
        }
        public static void CreateTest(string testName)
        {
            _test = _extentReports.CreateTest(testName);
        }

        public static void LogInfo(string message)
        {
            _test.Log(Status.Info, message);
        }
        public static void LogPass(string message)
        {
            _test.Log(Status.Pass, message);
        }

        public static void LogFail(string message)
        {
            _test.Log(Status.Fail, message);
        }

        public static void FlushReport()
        {
            _extentReports.Flush();
        }

    }
}
