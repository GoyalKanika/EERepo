﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleFramework.Utilities
{
    public class Base
    {
        protected IWebDriver driver;

        public Base(IWebDriver driver)
        {
            this.driver = driver;
        }
    }
}
