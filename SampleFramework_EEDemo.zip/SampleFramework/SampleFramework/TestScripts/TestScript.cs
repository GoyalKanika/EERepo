﻿
using AventStack.ExtentReports;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SampleFramework.PageObject;
using SampleFramework.Utilities;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Security.AccessControl;
using System.Security.Policy;
using System.Threading.Tasks;

namespace SampleFramework.TestScripts
{
    [TestFixture]
    public class TestScript
    {
        private IWebDriver driver;
        private Page genericPage;
        private string baseUrl = "https://www.expeditecommerce.com/";

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            ExtentReport.InitializeReport();
           
        }
        [SetUp]
        public void SetUp()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(baseUrl);
            driver.Manage().Window.Maximize();
            genericPage = new Page(driver);
            ExtentReport.CreateTest("CheckAllLinks");
        }

        [Test]
        public async Task CheckAllLinks()
        {
            List<string> brokenLinks = new List<string>();

            // Check anchor weblinks
            IList<IWebElement> anchorLinks = genericPage.GetAllAnchorLinks();
            foreach (var link in anchorLinks)
            {
                string url = link.GetAttribute("href");
                if (string.IsNullOrEmpty(url))
                {
                    ExtentReport.LogFail($"Link with empty href found: {link.Text}");
                    continue;
                }
                if (!await IsLinkValid(url))
                {
                    brokenLinks.Add(url);
                   // ExtentReport.LogFail($"Broken Link: {url}");
                }
                else
                {
                    ExtentReport.LogPass($"Valid Link: {url}");
                }
            }
           Assert.That(brokenLinks, Is.Empty, "There are broken links on the page.");
        }
        private async Task<bool> IsLinkValid(string url) //The method returns a Task that resolves to a bool. This allows the method to be awaited and indicates whether the URL is valid (true) or not (false).
        {
            int notFoundPageCount = 0;
            using (HttpClient client = new HttpClient()) //use HttpClient as long it is required and then dispose it off.
            {
                try
                {
                    var response = await client.GetAsync(url); //sends an async GET call to the url and then waits for it to respond and then stores the response of Get call
                    bool isValid = response.IsSuccessStatusCode;
                    if (isValid == false)
                    {
                        ExtentReport.LogFail($"Checked URL: {url}, Status Code: {(int)response.StatusCode}, Status Description: {response.StatusCode}");
                        Console.WriteLine($"Invalid URL: {url}, Status Code: {(int)response.StatusCode}, Status Description: {response.StatusCode}");
                        notFoundPageCount++;
                    }
                    // else
                    //    ExtentReport.LogPass($"Checked URL: {url}, Status Code: {(int)response.StatusCode}, Status Description: {response.StatusCode}");


                }
                /* catch (HttpRequestException ex)
                 {
                     ExtentReport.LogFail($"Error checking URL: {url}, Exception: {ex.Message}, Status Code: {ex.StatusCode}");

                 }
                 catch (Exception ex)
                 {

                     ExtentReport.LogFail($"Error checking URL: {url}, Exception: {ex.Message}");

                 }*/
                catch (Exception)
                {
                }
            }
                return (notFoundPageCount == 0);
            
        }
     

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
        [OneTimeTearDown]
        public void OneTimeTearDown()
        {
            ExtentReport.FlushReport();
        }
    }

    }

